#!/bin/bash

set -e

cd /home/app
bundle exec dashing start
